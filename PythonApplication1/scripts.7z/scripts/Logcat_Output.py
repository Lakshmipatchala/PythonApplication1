import subprocess
from ast import literal_eval
import re
import time
from traceback import format_exc as fe

date = time.strftime('%Y%m%d', time.localtime(time.time()))
timeStamp = str(time.time())
timeStamp = timeStamp[:timeStamp.index('.')]
fileTime = f"_{date}_{timeStamp}"

def delete_markup_string(text, ifSemanticInput = False):
    if ifSemanticInput:
        pattern = r'(\\u001b\\\\tn=([a-zA-Z0-9]+.*?)[\\]{0,2})'
    else:
        pattern = r'(\x1b.*?tn=([a-zA-Z0-9]+.*?)\\?)'
    res = re.findall(pattern, text)
    for r in res:
        text = text.replace(r[0], '')
    return text


def get_slot(slotDict):
    if not slotDict:
        return ""
    slotStr = ""
    for k, v in slotDict.items():
        slotStr += f"{k}={v[0].get('canonical')},"
    if slotStr:
        return slotStr
    else:
        return ''


def get_logic_operator_slots(nested_dict, _nluSlot, k, v):
    for key, value in nested_dict.items():
        if isinstance(value, dict):
            k += f'{key}.'
            get_logic_operator_slots(value, _nluSlot, k, v)
            k, v = '', None
        else:
            k += f'{key}.'
            k.strip('.')
            v = value
            _nluSlot[k] = v
    return _nluSlot


def parse_NLU_Output(mappingStr, stringBeCutted):
    if not mappingStr:
        return ''
    if stringBeCutted:
        match = re.search(r'\"alternatives\":\"(.*?)\"', mappingStr)
        if match:
            return f"The result json was cut. No ASR is to show.", "", "", ""
        else:
            return "", "", "", ""
        
    orthography = ""
    nluDict = eval(mappingStr.strip(), {'true': 'TRUE','false': 'False','null': 'None'})
    nluIntent, nluSlot = "", ""
    try:
        recommendation = nluDict.get('recommendation', '')
        if isinstance(recommendation, list):
            recommendation = nluDict.get('recommendation', '')[0]
    except:
        pass
    try:
        orthography = nluDict.get(recommendation).get('orthography', '')
    except:
        orthography = ''
    try:
        nluIntent = nluDict.get(recommendation).get('intents')[0].get('name', '')
    except:
        nluIntent = ''
    try:
        _nluSlot = nluDict.get(recommendation).get('intents')[0].get('slots', '')
        if "logic_operator_slots" in nluDict.get(recommendation).get('intents')[0]:
            logicOperatorSlots = nluDict.get(recommendation).get('intents')[0]['logic_operator_slots']
            logicOperatorSlotsKey, logicOperatorSlotsValue = '', None
            _nluSlot = get_logic_operator_slots(logicOperatorSlots, _nluSlot, logicOperatorSlotsKey, logicOperatorSlotsValue) 
    except:
        _nluSlot = ''
    nluSlot = get_slot(_nluSlot) 
    return orthography, recommendation, nluIntent, nluSlot



subprocess.run(["adb", "connect", "172.16.250.248"])
subprocess.run(["adb", "root"])
subprocess.run(["adb", "logcat", "-c"])

# sessionIDMarker = 'ark.core.base.LatencyMonitor'
sessionIDMarker = 'after mapping result = {'

adbProcess = subprocess.Popen(["adb", "logcat"], stdout=subprocess.PIPE)
try:
    with open(f'Logcat_Output{fileTime}.log', 'w', encoding = 'utf-8') as f:
        try:
            for line in iter(adbProcess.stdout.readline, b''):
                decodedLine = line.decode('latin-1').strip()
                mOnGetMapping = re.search('onProcessResult: (.*)', decodedLine)
                
                if sessionIDMarker in decodedLine:
                    try:
                        timeStr = ''
                        sessionID = ''
                        FinalUtteranceOfSessionID = ''
                        timeStampPattern = r"\b\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}\b"
                        match = re.search(timeStampPattern, decodedLine)
                        if match:
                            timeStr = match.group(0)
                        validStr = decodedLine[decodedLine.index(sessionIDMarker) + 23: decodedLine.rindex('}') + 1]
                        LatencyMonitorJson = eval(validStr.strip(), {'true': 'TRUE','false': 'False','null': 'None'})
                        if 'orthography' in LatencyMonitorJson:
                            FinalUtteranceOfSessionID = LatencyMonitorJson['orthography']
                        if 'session_id' in LatencyMonitorJson:
                            sessionID = LatencyMonitorJson['session_id']
                        if FinalUtteranceOfSessionID and sessionID:
                            print(f"\n{timeStr}\nVI:             {FinalUtteranceOfSessionID}\nSessionID:      {sessionID}")
                            f.write(f"\n\n{timeStr}\nVI:             {FinalUtteranceOfSessionID}\nSessionID:      {sessionID}")
                    
                    except:
                        print(f"\n{fe()}\n{decodedLine}\n")
                                    
                if "Final ASR result is::" in decodedLine:
                    validStr = decodedLine[decodedLine.index("Final ASR result is::") + 22:decodedLine.rindex("}  [") + 1]
                    validStr = eval(validStr.strip(), {'true': 'TRUE','false': 'False','null': 'None'})
                    finalASR = validStr.get("orthography", "")
                
                if mOnGetMapping:
                    if not ('wuw_sds' in decodedLine or 'timeout_ls' in decodedLine):
                    # if True:
                        stringBeCutted = False
                        mappingStr = mOnGetMapping.group(1)
                        if mappingStr:
                            timeStr = 'Not time Found'
                            timeStampPattern = r"\b\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}\b"
                            match = re.search(timeStampPattern, decodedLine)
                            if match:
                                timeStr = match.group(0)
                            try:
                                mappingStr = mappingStr[:mappingStr.index('}  [') + 1]
                            except:
                                stringBeCutted = True
                            if mappingStr:
                                orthography, recommendation, nluIntent, nluSlot = parse_NLU_Output(mappingStr, stringBeCutted)
                                if (not orthography and finalASR) or (orthography == "The result json was cut. No ASR is to show." and finalASR):
                                    orthography = finalASR
                                    recommendation, nluIntent, nluSlot = "Not Found", "Not Found", "Not Found"
                                print(f"\n{timeStr}\nVI:             {orthography}\nRecommendation: {recommendation}\nIntent:         {nluIntent}\nSlot:           {nluSlot}")
                                f.write(f"\n\n{timeStr}\nVI:             {orthography}\nRecommendation: {recommendation}\nIntent:         {nluIntent}\nSlot:           {nluSlot}")
                                
                if "getNLGFacets interactionType:" in decodedLine and "GLO_T_TopLevel" not in decodedLine:
                    facet = ''
                    if '| path:' in decodedLine:
                        facet = decodedLine[decodedLine.index('| facetNames:')+13:decodedLine.index('| path:')].strip()
                    else:
                        facet = decodedLine[decodedLine.index('| facetNames:')+13:decodedLine.index('| NLG content:')].strip()
                    NLGContentDict = eval(decodedLine[decodedLine.index('| NLG content:')+14:decodedLine.rindex('|')].strip())
                    try:
                        if facet == 'text,tts':
                            try:
                                text = NLGContentDict['text']['surface']
                            except:
                                try:
                                    text = NLGContentDict['tts']['surface']
                                except:
                                    text = ''
                        else:
                            text = NLGContentDict['hints']['surface']
                    except KeyError:
                        text = ''
                    text = delete_markup_string(text)
                    print(f"VO FROM NLG: \n        ----{text}")
                    f.write(f"\nVO FROM NLG: \n        ----{text}")
                    
                if "prompting begin text =" in decodedLine:
                    text = ''
                    text = decodedLine[decodedLine.index('prompting begin text =')+23:].strip()
                    if text:
                        print(f"VO FROM Field <prompting begin text>: \n        ----{text}")
                        f.write(f"\nVO FROM Field <prompting begin text>: \n        ----{text}")
        except KeyboardInterrupt:
            print("\nAbort, saves data and exits")
                    
except Exception as e:
    print(f"\nSave the output to file > Logcat_Output{fileTime}.log")
else:
    print(f"\nSave the output to file > Logcat_Output{fileTime}.log")