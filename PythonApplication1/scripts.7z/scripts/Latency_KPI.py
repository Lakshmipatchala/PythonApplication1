import re
import json
import sys
import xlsxwriter
from datetime import datetime

"""
Using by: py Latency_KPI.py <log_file_abs_path>
The output is the latency of each commands including wakeup-word
"""


WAKE_UP_WORD = [
    'hey porsche',
    'hi porsche'
]

# END_OF_RECOGNITION = 'ark.core.api.RecognitionComposerListenerImpl send result'
# END_OF_RECOGNITION = 'ark.core.asr_ext.RecognitionComposer     stopRecognitionInternal returned'
# END_OF_COMMAND = 'recognizer_speech_end'
LATENCY_MONITOR = re.compile('(^.+)(ark\\.core\\.base\\.LatencyMonitor)(\s+)(\\{.+}).+\[\d+\]$')
BEFORE_PROMPT = 'ace.engine.*Notification is::.*PROMPT_BEGIN.*'
ARK_CORE_TIME_MARKER = 'ark.core.base.TimeMarker'


def get_latency(log_file):
    keyLogLines = []
    standardLogTime, standardTimestamp = 0, 0
    latencyList = []
    with open(log_file, 'r', encoding = 'utf-8', errors='ignore') as f:
        logContent = f.readlines()
        for line in logContent:
            latencyMonitorMatcher = LATENCY_MONITOR.match(line)
            promptBeginMatcher = re.search(BEFORE_PROMPT, line)
            if not standardLogTime and not standardTimestamp:
                standardLogTime, standardTimestamp = get_standard_timeMarker(logContent)
            if latencyMonitorMatcher:
                latencyMonitorJson = json.loads(latencyMonitorMatcher.group(4))
                utterance = latencyMonitorJson["record"]["final_result"]["utterance"]
                utteranceType = latencyMonitorJson["record"]["final_result"]["type"]
                eos = latencyMonitorJson["record"]["eos"]
                speechEndLogTime = get_speech_end_log_time(standardLogTime, standardTimestamp, eos)
                latencyList.append(speechEndLogTime)
                latencyList.append(utterance)
                keyLogLines.append(line)
            elif promptBeginMatcher:
                logTime = get_log_time(line)
                latencyList.append(logTime)
                keyLogLines.append(line)
                
    # with open('KeylogLine.log', 'w', encoding='utf-8') as f:
    #     f.write(''.join(keyLogLines))
        
    calculate_latency(latencyList)


def format_logTime(timeString):
    def time_to_milliseconds(timeString):
        time_format = "%H:%M:%S.%f"
        dt = datetime.strptime(timeString, time_format)
        milliseconds = (dt.hour * 3600 + dt.minute * 60 + dt.second) * 1000 + dt.microsecond // 1000
        return milliseconds
    
    timeString = timeString.strip()
    if timeString.count(':') == 1:
        timeString = f"00:{timeString}"
    timeString = time_to_milliseconds(timeString)
    return timeString


def get_standard_timeMarker(logContent):
    for line in logContent[::-1]:
        matcher5 = re.search(ARK_CORE_TIME_MARKER, line)
        if matcher5:
            standardLogTime, standardTimestamp = get_standard_log_time(line)
            # print(standardLogTime, standardTimestamp)
            return standardLogTime, standardTimestamp


def get_log_time(line):
    logTime = 0
    # # logcat system log
    # if 'pal/stdout:' in line:
    #     logTime = line[line.index('pal/stdout:')+11:line.index('CORE_INFO:')]
    #     logTime = format_logTime(logTime)
    # # sdk log
    # elif line[0].isdigit():
    #     logTime = line[:line.index('CORE_INFO:')]
    #     logTime = format_logTime(logTime)
        
    pattern = r'((\d{2}:)?\d{2}:\d{2}\.\d+ +CORE_INFO)'
    matches = re.findall(pattern, line)
    if matches:
        logTime = matches[0][0]
        logTime = logTime[:logTime.index('CORE_INFO')].strip()
        logTime = format_logTime(logTime)
    return int(logTime)


def get_standard_log_time(line):
    standardLogTime = get_log_time(line)
    timeMarkerJson = line[line.index('{'):line.rindex('}')+1]
    timeMarkerJson = eval(timeMarkerJson, {'true': 'TRUE','false': 'False','null': 'None'})
    standardTimestamp = timeMarkerJson['timestamp']
    return standardLogTime, standardTimestamp


def get_speech_end_log_time(standardLogTime, standardTimestamp, eos):
    standardLogTime = int(standardLogTime)
    standardTimestamp = int(standardTimestamp)
    eos = int(eos)
    speechEndTime = 0
    if eos > standardTimestamp:
        speechEndTime = eos - standardTimestamp + standardLogTime        
    else:
        speechEndTime = standardLogTime - standardTimestamp + eos
    return speechEndTime


def calculate_latency(latencyList):
    fileName = 'MACAN_LATENCY_TEST_REPORT.xlsx'
    workbook = xlsxwriter.Workbook(fileName)
    wakeUplatencyList = []
    commandsList = []
    for index, item in enumerate(latencyList):
        if isinstance(item, int):
            pass
        elif item.lower().replace(' ', '') in [x.lower().replace(' ', '') for x in WAKE_UP_WORD]:
            wakeUplatencyList.append([item, latencyList[index+1] - latencyList[index-1]])
        else:
            commandsList.append([item, latencyList[index+1] - latencyList[index-1]])
    
    print("Command -> KPI Latency")
    for item in wakeUplatencyList:
        print(f"{item[0]} -> {item[1]}")
    for item in commandsList:
        print(f"{item[0]} -> {item[1]}")
    
    # make_latency_report(workbook, commandsList, 'Wakeup_Latency_Data')
    # make_latency_report(workbook, wakeUplatencyList, 'Command_Latency_Data')
    # workbook.close()

def make_latency_report(workbook, latencyList, sheetName):
    worksheet = workbook.add_worksheet(sheetName)
    widthDict = {'A:A': 20, 'B:B': 15}
    titleFormat = workbook.add_format(
        {
            'text_wrap': True,
            'border': True,
            'bold': True,
            'align': 'center',
            "bg_color": '209505',
            "font_color": 'ffffff',
            'font_size': '10',
            'font_name': 'Arial',
            'valign': 'vcenter'
        }
    )
    title = [
        'Utterance',
        'Latency'
    ]
    
    for w in widthDict:
        worksheet.set_column(w, widthDict[w])
    
    row = 0
    for col in range(0, len(title)):
        worksheet.set_row(row, 50)
        worksheet.write(row, col, title[col], titleFormat)
    
    row = 0
    for command, latency in latencyList:
        row += 1
        worksheet.write(row, 0, command)
        worksheet.write(row, 1, latency)
        

if __name__ == '__main__':
    """
    command:
    py Latency_KPI.py <log_file_abs_path>
    """
    if len(sys.argv) < 2:
        print('USAGE: {} LOG_FILE'.format(sys.argv[0]))
        exit(1)
    
    get_latency(sys.argv[1])
    
    # log_file = r'C:\Users\chendong.li\Downloads\OneDrive_1_2024-5-10\MAC_RecLat_Offb_Stock_log_20240507.log'
    # get_latency(log_file)
    